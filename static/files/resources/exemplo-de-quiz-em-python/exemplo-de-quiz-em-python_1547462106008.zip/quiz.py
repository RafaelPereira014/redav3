import random

perguntas=[]
repostaa=[]
repostab=[]
repostac=[]
repostad=[]
certas=[]
pontos=0

f=open("perguntas.txt","r")
l=1

for i in f:
	i=i[0:len(i)-1] #tira o caracter de nova linha do fim
	if l==1:
		perguntas.append(i)
	if l==2:
		repostaa.append(i)
	if l==3:
		repostab.append(i)
	if l==4:
		repostac.append(i)
	if l==5:
		repostad.append(i)
	if l==6:
		certas.append(i)
	l+=1
	if l>6:
		l=1
f.close()

while len(perguntas)>0:
  p=random.randint(0,len(perguntas)-1)
  print("\nPontos [",pontos,"]\n")
  print(perguntas.pop(p))
  print("a - ",repostaa.pop(p))
  print("b - ",repostab.pop(p))
  print("c - ",repostac.pop(p))
  print("d - ",repostad.pop(p))
  o=input("> ")
  if o==certas.pop(p):
    print("CERTO!!!")
    pontos+=10
  else:
    print("Errado!!")
    pontos-=10
  if pontos<0: 
    pontos=0

print("\nPontuacao final --> ",pontos)
